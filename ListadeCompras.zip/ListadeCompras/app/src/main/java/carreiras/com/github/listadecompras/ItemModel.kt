package carreiras.com.github.listadecompras

import java.math.BigDecimal
import java.time.LocalDateTime

data class ItemModel(
    val name: String,
    val preco: BigDecimal,
    val desc: String,
    val onRemove: (ItemModel) -> Unit,
    val data: LocalDateTime
)
