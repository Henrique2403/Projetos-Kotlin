package carreiras.com.github.listadecompras

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDateTime

class MainActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView);
        val itemsAdapter = ItemsAdapter()
        recyclerView.adapter = itemsAdapter

        val button = findViewById<Button>(R.id.button)
        val editTextNome = findViewById<EditText>(R.id.editTextNome)
        val editTextPreco = findViewById<EditText>(R.id.editTextPreco)
        val editTextDescricao = findViewById<EditText>(R.id.editTextDescricao)

        button.setOnClickListener {
            if (editTextNome.text.isEmpty() && editTextPreco.text.isEmpty() && editTextDescricao.text.isEmpty()) {
                editTextNome.error = "Preencha um valor"
                editTextPreco.error = "Preencha um valor"
                editTextDescricao.error = "Preencha um valor"
                return@setOnClickListener
            }

            val item = ItemModel(
                name = editTextNome.text.toString(),
                preco = editTextPreco.text.toString().toBigDecimal(),
                desc = editTextDescricao.text.toString(),
                data = LocalDateTime.now(),
                onRemove = {
                    itemsAdapter.removeItem(it)
                },

                )

            Log.d("Tag", "$item")

            itemsAdapter.addItem(item)
            editTextNome.text.clear()
            editTextPreco.text.clear()
            editTextDescricao.text.clear()
        }
    }
}
